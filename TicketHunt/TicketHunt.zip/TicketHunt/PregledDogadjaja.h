#pragma once
#pragma once
#ifndef PREGLED_DOGADJAJA_H
#define PREGLED_DOGADJAJA_H
#define MAX 30
#include <string.h>

void PregledDogadjaja();

#endif