#ifndef OTKAZIVANJE_KUPLJENE_ULAZNICE_H
#define OTKAZIVANJE_KUPLJENE_ULAZNICE_H
#define MAX 20
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void otkazivanjeKupljeneUlaznice(char* korisnickoIme);
void obrisiLiniju(int broj_linije);
void brisanjeLinije_drugifajl(int broj_linije);
#endif