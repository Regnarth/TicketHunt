#pragma once
#ifndef PRVI_ADMINISTRATOR_H
#define PRVI_ADMINISTRATOR_H
// PRVI_ADMINISTRATOR_H
#include "Registracija.h"

int prviAdministrator(USER*);
int istaSifra(char* sifra1, char* sifra2);

#endif