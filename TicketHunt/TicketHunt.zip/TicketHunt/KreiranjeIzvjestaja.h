#pragma once
#ifndef KREIRANJE_IZVJESTAJA_H
#define KREIRANJE_IZVJESTAJA_H
// KREIRANJE_IZVJESTAJA_H

#include "KreiranjeDogadjaja.h"

void PronadjiUlaznice(struct Datum datum, char* naziv);
void KreiranjeIzvjestaja();



#endif
