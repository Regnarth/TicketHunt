#ifndef PONISTAVANJE_SIFRE_H
#define PONISTAVANJE_SIFRE_H
// PONISTAVANJE_SIFRE_H
#define MAX 20
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void ponistiSifru();
int provjeraPostojanja(FILE* f, char* korisnickoIme);
int memorisiSifru(FILE* f, char* korisnickoIme);

#endif
