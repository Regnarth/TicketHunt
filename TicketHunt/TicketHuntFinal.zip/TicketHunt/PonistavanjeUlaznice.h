#ifndef PONISTAVANJE_ULAZNICE_H
#define PONISTAVANJE_ULAZNICE_H
#define MAX 20
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#endif
char sifra_ulaznice[10];
void ponistavanjeUlaznice();
int validacijaSifre(char* sifra);
