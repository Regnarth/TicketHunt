#pragma once
#pragma once
#ifndef PREGLED_DOGADJAJA_H
#define PREGLED_DOGADJAJA_H
#define MAX 20
#include <string.h>

void PregledDogadjaja();

#endif