#pragma once
#ifndef PREGLED_NALOGA_H
#define PREGLED_NALOGA_H
// PREGLED_NALOGA_H
void pregledNaloga();


#endif