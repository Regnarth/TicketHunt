#pragma once
#pragma once
#ifndef PREGLED_ULAZNICA_H
#define PREGLED_ULAZNICA_H
#define MAX 20

void pregled_prodatih_ulaznica();

#endif